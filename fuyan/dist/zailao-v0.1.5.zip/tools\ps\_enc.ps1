$path = 'D:\学习资料\测试.zip'
$bytes = [System.Text.Encoding]::UTF8.GetBytes($path)
$stdout = [Console]::OpenStandardOutput()
$stdout.Write($bytes, 0, $bytes.Length)
$stdout.Flush()
