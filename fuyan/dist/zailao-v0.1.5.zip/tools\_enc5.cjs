const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const ps = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const file = path.join(__dirname, 'ps', '_enc.ps1');
execFile(ps, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', file], { encoding: 'buffer' }, (err, stdout) => {
  if (err) { console.log('ERR', err.message); return; }
  fs.writeFileSync(path.join(__dirname, '_enc_out.bin'), stdout);
  console.log('bytes', stdout.toString('hex'));
});
